
<?php
    $saskibaloEstatistikak = [
        'JokalariA' => [
            'puntuak' => 24,
            'erreboteak' => 10,
            'asistentziak' => 5,
        ],
        'JokalariB' => [
            'puntuak' => 18,
            'erreboteak' => 12,
            'asistentziak' => 7,
        ],
        'JokalariC' => [
            'puntuak' => 22,
            'erreboteak' => 9,
            'asistentziak' => 4,
        ],
    ];
?>


<table border=1>
    <tr>
        <th>Izena</th>
        <th>Puntuak</th>
        <th>Erreboteak</th>
        <th>Asistentziak</th>
    </tr>
    <?php $__currentLoopData = $saskibaloEstatistikak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item); ?></td>
            <td><?php echo e($value['puntuak']); ?></td>
            <td><?php echo e($value['erreboteak']); ?></td>
            <td><?php echo e($value['asistentziak']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php /**PATH C:\xampp\htdocs\DWES\DWES---Natalia-entregak\natalia_lamego_simbaña\azterketa\resources\views/saski_bista.blade.php ENDPATH**/ ?>